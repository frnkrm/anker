@echo off
chcp 65001 >nul
node "%~dp0signieren.mjs"
echo.
pause
